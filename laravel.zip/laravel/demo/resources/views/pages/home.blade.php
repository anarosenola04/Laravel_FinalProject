@extends('layout.master')
@section('title')
Events Management System
@endsection

@section('content')


<nav class="navbar navbar-expand-lg navbar-light " style="background-color: #C0C0C0;">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Modified CRUD Demo</a>


    </div>
    </div>
</nav>

<h1 class="pb-5 text-center fw-bold pt-5">
    Events Management System
</h1>
<br>
<a href="{{route('tasks.create')}}" id="a_addEvent">
    <button id="btn">
        <i class="fas fa-cloud" style="font-size:15px;"></i>
        &nbsp;Add Event
    </button>
</a>

<br><br><br>
<div class="row" id="div_box1">
    @foreach ($tasks as $task)
    <div class="col-md-4 mb-5">
        <div class="bg-primary fs-2" id="relative">
            <form action="{{route('tasks.destroy', $task->id)}}" method="post">
                @csrf
                @method('delete')
                <div id="topright">
                    <button data-bs-toggle="modal" data-bs-target="#staticBackdrop1" type="button" id="btn_x">
                        <i class="bi bi-x-square-fill" style="font-size:35px; color:red;"></i>
                    </button>
                    <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-danger" id="staticBackdropLabel1">DELETE EVENT!</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to delete this event?
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-danger">DELETE THIS EVENT</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <i class="bi bi-calendar4-week"></i>
                
        </div>

        <div class="modal-body text-center shadow">
         <h1>  {{$task->task_column}} </h1>
            <br><br><br>
            <a class="mb-3 btn btn-info" href="{{route('tasks.show', $task->id)}}">
                <i class="bi bi-info-square"></i>&nbsp;View</a>
            <a class="mb-3 btn btn-secondary" href="{{route('tasks.edit', $task->id)}}" id="edit">
                <i class="bi bi-pencil-square"></i>&nbsp; Edit</a>
        </div>
    </div>
    @endforeach
</div>


@endsection