@extends('layout.master')
@section('title')
    Specific Task
@endsection

@section('content')

<!----mao ni ang view page--->
<div class="mt-4 pb-3 container" id="div_add_1">
                <label class="card-title pt-5 fw-bold fs-5" id="add_event_h5">EVENT DETAILS </label>
                    <br><br>
                    
                        <label class="col-sm-3 col-form-label fw-bold" style="margin-left:150px;"><h3>EVENT NAME : {{$task->task_column}}</h3></label>

                        <br><br><br>

                        <label class="col-sm-3 col-form-label fw-bold" style="margin-left:150px;"><h3>SCHEDULE: {{$task->date}}</h3></label>

                        <br><br><br>

                        <label class="col-sm-3 col-form-label fw-bold" style="margin-left:150px;"><h3>VENUE: {{$task->venue}}</h3></label>
  
                        <br><br><br>

                        <label class="col-sm-3 col-form-label fw-bold" style="margin-left:150px;"><h3>IN CHARGE: {{$task->incharge}}</h3></label>

                        <br><br>
                        <a class="mb-3 btn btn-secondary" href="{{route('tasks.index')}}">Back</a>
                        
</div>


@endsection
